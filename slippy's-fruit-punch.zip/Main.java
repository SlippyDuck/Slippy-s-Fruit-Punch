import com.sun.net.httpserver.HttpServer;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpExchange;
import java.io.*;
import java.net.InetSocketAddress;
import java.nio.file.Files;
import java.util.Random;

public class Main {

    public static void main(String[] args) throws IOException {
        HttpServer server = HttpServer.create(new InetSocketAddress("0.0.0.0", 3000), 0);
        
        server.createContext("/", new FileHandler());
        
        server.createContext("/api/spin", new SpinHandler());
        
        System.out.println("=========================================");
        System.out.println("   SLOT MACHINE SYSTEM STARTING UP...    ");
        System.out.println("   Server Address: http://0.0.0.0:3000   ");
        System.out.println("=========================================");
        server.start();
    }

    static class FileHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            try {
                String path = exchange.getRequestURI().getPath();
                System.out.println("Request received for: " + path);
                
                if (path.equals("/")) {
                    path = "/index.html";
                }

                File file = new File(path.substring(1));

                if (file.exists() && !file.isDirectory()) {
                    byte[] bytes = Files.readAllBytes(file.toPath());
                    
                    if (path.endsWith(".html")) {
                        exchange.getResponseHeaders().set("Content-Type", "text/html");
                    } else if (path.endsWith(".css")) {
                        exchange.getResponseHeaders().set("Content-Type", "text/css");
                    }

                    exchange.sendResponseHeaders(200, bytes.length);
                    OutputStream os = exchange.getResponseBody();
                    os.write(bytes);
                    os.close();
                    System.out.println("Served: " + path + " (" + bytes.length + " bytes)");
                } else {
                    System.out.println("File not found: " + path);
                    String error = "404 Not Found: " + path;
                    exchange.sendResponseHeaders(404, error.length());
                    OutputStream os = exchange.getResponseBody();
                    os.write(error.getBytes());
                    os.close();
                }
            } catch (Exception e) {
                System.out.println("Error in FileHandler: " + e.getMessage());
                e.printStackTrace();
                exchange.sendResponseHeaders(500, -1);
                exchange.close();
            }
        }
    }

    static class SpinHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            try {
                if ("POST".equals(exchange.getRequestMethod())) {
                    
                    Random random = new Random();
                    String s1 = getWeightedSymbol(random.nextInt(1000));
                    String s2 = getWeightedSymbol(random.nextInt(1000));
                    String s3 = getWeightedSymbol(random.nextInt(1000));

                    int win = 0;
                    String message = "You lost! Try again.";

                    if (s1.equals(s2) && s2.equals(s3)) {
                        win = 50; 
                        message = "JACKPOT!";
                    } 
                    else if (s1.equals(s2) || s2.equals(s3) || s1.equals(s3)) {
                        win = 2;
                        message = "Pair!";
                    }

                    String response = "{" +
                        "\"s1\": \"" + s1 + "\"," +
                        "\"s2\": \"" + s2 + "\"," +
                        "\"s3\": \"" + s3 + "\"," +
                        "\"win\": " + win + "," +
                        "\"message\": \"" + message + "\"" +
                    "}";

                    byte[] responseBytes = response.getBytes("UTF-8");
                    exchange.getResponseHeaders().set("Content-Type", "application/json; charset=UTF-8");
                    exchange.sendResponseHeaders(200, responseBytes.length);
                    
                    OutputStream os = exchange.getResponseBody();
                    os.write(responseBytes);
                    os.close();
                    
                    System.out.println("Java processed a spin: " + s1 + " " + s2 + " " + s3);
                } else {
                    exchange.sendResponseHeaders(405, -1);
                    exchange.close();
                }
            } catch (Exception e) {
                System.out.println("Error in SpinHandler: " + e.getMessage());
                exchange.sendResponseHeaders(500, -1);
                exchange.close();
            }
        }

        static String getWeightedSymbol(int value) {
            if (value < 1) return "7️⃣";   // 0.1%
            if (value < 15) return "💎";  // 1.4%
            if (value < 50) return "🔔";  // 3.5%
            if (value < 120) return "🍋"; // 7%
            if (value < 300) return "🍒"; // 18%
            if (value < 500) return "🍉"; // 20% (Low Tier)
            if (value < 750) return "🍇"; // 25% (Low Tier)
            return "🍊";                  // 25% (Low Tier)
        }
    }
}
