# Slippy's Fruit Punch

Its a slot machine. Click spin and hope you win money. Made by Lim.

## What is this?
its a website with a java backend. the java does the math so you cant cheat easily hopefully.

## How to make start?
if you have npm just do this:
`npm run dev`

It runs the java command `javac Main.java \&\& java Main`. It starts on port 3000. Go to localhost:3000 in your browser.

## files
- Main.java: the brain, it does the spins.
- index.html: the buttons and stuff.
- style.css: makes it look nice.

## rules
- **3 of a kind** = Jackpot (50x your bet)
- **2 of a kind** = Pair (2x your bet)
- **Everything else** = You lose your bet.

### Symbols & Rarity
The machine is now balanced so the house has a slight edge.
- 7️⃣ **Jackpot** (0.1%) - 50x Payout
- 💎 **Epic** (1.4%) - 50x Payout
- 🔔 **Rare** (3.5%) - 50x Payout
- 🍋 **Uncommon** (7%) - 50x Payout
- 🍒 **Common** (18%) - 50x Payout
- 🍉/🍇/🍊 **Junk** (70% combined) - These make it harder to get a match!